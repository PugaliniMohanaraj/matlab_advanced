A = imread('Figure 3.jpg');
figure
imshow(A);

disp('Size of image A :')
size(A)
R=A(:,:,1);
G=A(:,:,2);
B=A(:,:,3);
subplot(2,2,1)
imshow(A);
title('The original image')
subplot(2,2,2)
imshow(R);
title('The red layer')
subplot(2,2,3)
imshow(G);
title('The green layer')
subplot(2,2,4)
imshow(B);
title('The blue layer')

%BW
BW=rgb2gray(A);
figure
imshow(BW)
title('The gryscale image')
