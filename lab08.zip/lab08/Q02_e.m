subplot(2,2,1) 
phoneRotate(1435) 
title(' Angle 1435'); 

subplot(2,2,2) 
phoneRotate(-273) 
title(' Angle -273');

subplot(2,2,3) 
phoneRotate(-200) 
title(' Angle -200');

subplot(2,2,4) 
phoneRotate(646) 
title(' Angle 646');