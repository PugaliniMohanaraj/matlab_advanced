red_piece=A(:,:,1); 
%finding the suitable threshold 
T=255*graythresh(red_piece); 

k=ones(25,25); 
k=k/(sum(sum(k))); 
 
red_piece=imfilter(red_piece,k); 

B_R=red_piece>T; 
figure  
imshow(B_R) 
title('Binary Images of red pieces part-g') 
%no of red pieces 
[~,no_r]=bwlabel(B_R); 
disp('No of Red pieces in the Image') 
no_r 