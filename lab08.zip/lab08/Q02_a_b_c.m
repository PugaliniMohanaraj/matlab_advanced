%a part
P = imread('Figure 4.jpg');
L = imread('Figure 5.jpg');

%b part
PCW=imrotate(P,-45);
PACW=imrotate(P,45);

figure
subplot(1,2,1)
imshow(PCW)
title('Rotated 45 degree in clock wise')

subplot(1,2,2)
imshow(PACW)
title('Rotated 45 degree in anticlock wise')

%C part
PFH=flip(P,2);
PFV=flip(P,1); 
 
figure
subplot(1,2,1)
imshow(PFH)
title('The figure was flipped in horizontally')

subplot(1,2,2)
imshow(PFV)
title('The figure was flipped in vertically')
