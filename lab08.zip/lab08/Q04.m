%a
imhist(BW) 
title('Gray scale histogram') 
figure 
imshow(BW)
%c
T=255*graythresh(BW);
%d
B=BW>T;
figure
subplot(1,2,1)
imshow(BW)
title('grayscale image')

subplot(1,2,2)
imshow(B)
title('binary image')

%e
k=ones(25,25); 
k=k/(sum(sum(k)));  
BW=imfilter(BW,k); 

% Binary image 
B=BW>T; 

figure  
subplot(1,2,1) 
imshow(BW) 
title('BW grayscale image after blurred'); 

subplot(1,2,2) 
imshow(B) 
title('Binary image after blurred'); 

% f 
[~,n]=bwlabel(B); 
disp('No of Toy pieces in the Binary Image') 
n 