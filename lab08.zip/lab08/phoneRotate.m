%Q02_d
function phoneRotate(a)
P = imread('Figure 4.jpg');
L = imread('Figure 5.jpg');

y=mod(a,360);
x=abs(y);

if x>=0 && x<=45 
R=imrotate(P,x); 
elseif x>45 && x<=135 
R=imrotate(L,x); 
elseif x>135 && x<=225 
R=imrotate(P,x); 
elseif x>225 && x<=315 
R=imrotate(L,x); 
elseif x>315 && x<=360 
R=imrotate(P,x); 
end 

imshow(R) 
end 

%Q02_e
%2022e098


