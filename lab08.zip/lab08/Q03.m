%Q03_a
k=ones(21,21);

%Q03_b
k=k/sum(sum(k));

%Q03_c
H=imread('Figure 12.jpg');
blur=imfilter(H,k);

%Q03_d
figure
imshow(blur)
title('Blur image')
